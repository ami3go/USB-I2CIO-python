//---------------------------------------------------------------------------
// Copyright (c) 2003 Jay Crawford 
#include <vcl.h>
#pragma hdrstop

#include "Demo_Unit1.h"
#include "usbi2cio_bcb_v5.h"  // Modified Header file to support BCB

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

// SETUP SOME GLOBAL VARIALBES
BOOL flag;

LONG *IoRead;
LONG ulIoPortConfig;
HANDLE hDevice[127];
I2C_TRANS TransI2C;
HINSTANCE hDLL;


//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
        if(!flag)   // Check to see if USB Enabled already, if not give it a try
        {
                // Going to open the first instance
                hDevice[0] = INVALID_HANDLE_VALUE;
                hDevice[0] = DAPI_OpenDeviceInstance("UsbI2cIo", 0);
                //  flag=flag;

                if(hDevice[0] == INVALID_HANDLE_VALUE)
                {
                        flag=false;
                        StatusBar1->Panels->Items[0]->Text ="Unable to Connect to USB"  ;
                }
                else
                {
                        flag = true;
                        StatusBar1->Panels->Items[0]->Text= "Connected to USB"  ;
                }
        }
}

//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
        if(flag )
        {
                flag= DAPI_CloseDeviceInstance(hDevice[0]);
                StatusBar1->Panels->Items[0]->Text= "Dis-connected from USB"  ;
                flag = !flag;
        }

        //flag=flag;
}


void __fastcall TForm1::Button3Click(TObject *Sender)
{

AnsiString idser = "00000000" ; // seed serial string
bool idok = false;

        if(flag)
        {  // Only Execute if USB has been enabled
                idok = DAPI_GetSerialId(hDevice[0], idser.c_str());
                StatusBar1->Panels->Items[1]->Text = "The Devasys USB Serial Number is : " + idser;
        }
        else
                StatusBar1->Panels->Items[1]->Text = "USB Not Enabled - No Serial Number Available"  ;
}
//---------------------------------------------------------------------------




