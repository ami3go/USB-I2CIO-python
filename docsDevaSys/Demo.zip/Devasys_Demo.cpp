//---------------------------------------------------------------------------
// Copyright (c) 2003 Jay Crawford 
#include <vcl.h>
#pragma hdrstop
USERES("Devasys_Demo.res");
USELIB("bcb_usbi2cio.lib");
USEFORM("Demo_Unit1.cpp", Form1);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
